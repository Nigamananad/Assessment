package com.example.apnibookproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.apnibookproject.databinding.ActivityStockBookBinding

class StockBookActivity : AppCompatActivity() {
    lateinit var binding: ActivityStockBookBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityStockBookBinding.inflate(layoutInflater)
        setContentView(binding.root)


    }
}