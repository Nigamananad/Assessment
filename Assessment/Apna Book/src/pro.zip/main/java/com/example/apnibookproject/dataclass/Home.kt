package com.example.apnibookproject.dataclass

data class Home(
    var id:Int,
    var image:Int,
    var name:String
)
