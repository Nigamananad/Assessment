package com.example.apnibookproject

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import com.example.apnibookproject.Adapter.HomeListAdapter
import com.example.apnibookproject.databinding.FragmentHomeBinding
import com.example.apnibookproject.dataclass.Home

class HomeFragment : Fragment() {

    lateinit var binding: FragmentHomeBinding
    lateinit var hAdapter: HomeListAdapter
    var homeList= mutableListOf<Home>()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {
//        binding=FragmentHomeBinding.inflate(layoutInflater,container,false)
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home,container,false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        homeList.add(Home(1,R.drawable.client,"Client Book"))
        homeList.add(Home(2,R.drawable.dollar,"Business Book"))
        homeList.add(Home(3,R.drawable.warehouse,"Stock Book"))
        homeList.add(Home(4,R.drawable.wallet,"Expense Book"))

        hAdapter= HomeListAdapter(requireContext(),homeList)
        binding.horizontalView.layoutManager= GridLayoutManager(requireContext(),2)
        binding.horizontalView.adapter=hAdapter
    }

}