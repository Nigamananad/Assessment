package com.example.apnibookproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.ActionBarDrawerToggle
import com.example.apnibookproject.databinding.ActivityNavigationDrawerBinding

class NavigationDrawerActivity : AppCompatActivity() {
    lateinit var binding: ActivityNavigationDrawerBinding
    lateinit var drawerToggle: ActionBarDrawerToggle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNavigationDrawerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.appBar.toolBar.title = "Home"
        setSupportActionBar(binding.appBar.toolBar)

        drawerToggle = ActionBarDrawerToggle(
            this,
            binding.drawerLayout,
            binding.appBar.toolBar,
            R.string.nav_open,
            R.string.nav_close
        )
        binding.drawerLayout.addDrawerListener(drawerToggle)
        drawerToggle.syncState()


        supportFragmentManager.beginTransaction().apply {
            add(binding.appBar.toolBar.id, HomeFragment())
            addToBackStack(null)
            commit()
        }
    }
}